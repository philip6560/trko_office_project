
import 'package:flutter/material.dart';

class MyStyle{
  static const darkblue = Color.fromRGBO(2, 56, 89, 1.0);
  static const greenish = Color.fromRGBO(128, 185, 192, 1.0);
  static const whitishred = Color.fromRGBO(165, 165, 165, 1.0);
  static const white = Color.fromRGBO(225, 225, 225, 1.0);
}