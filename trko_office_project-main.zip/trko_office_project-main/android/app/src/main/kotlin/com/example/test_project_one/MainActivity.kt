package com.example.test_project_one

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
